cmd_usr/include/asm/hwcap.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/arch/arm64/include/uapi/asm/hwcap.h usr/include/asm/hwcap.h
