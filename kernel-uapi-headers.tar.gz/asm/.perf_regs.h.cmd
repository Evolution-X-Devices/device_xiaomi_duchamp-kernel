cmd_usr/include/asm/perf_regs.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/arch/arm64/include/uapi/asm/perf_regs.h usr/include/asm/perf_regs.h
