cmd_usr/include/asm/statfs.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/arch/arm64/include/uapi/asm/statfs.h usr/include/asm/statfs.h
