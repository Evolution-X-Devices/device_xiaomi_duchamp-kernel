cmd_usr/include/asm/sembuf.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/sembuf.h usr/include/asm/sembuf.h
