cmd_usr/include/asm/socket.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/socket.h usr/include/asm/socket.h
