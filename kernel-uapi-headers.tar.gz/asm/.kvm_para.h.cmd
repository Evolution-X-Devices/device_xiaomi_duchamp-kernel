cmd_usr/include/asm/kvm_para.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/kvm_para.h usr/include/asm/kvm_para.h
