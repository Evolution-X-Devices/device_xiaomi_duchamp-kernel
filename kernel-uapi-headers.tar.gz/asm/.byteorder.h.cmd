cmd_usr/include/asm/byteorder.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/arch/arm64/include/uapi/asm/byteorder.h usr/include/asm/byteorder.h
