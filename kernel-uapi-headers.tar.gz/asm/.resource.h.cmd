cmd_usr/include/asm/resource.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/resource.h usr/include/asm/resource.h
