cmd_usr/include/asm/sigcontext.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/arch/arm64/include/uapi/asm/sigcontext.h usr/include/asm/sigcontext.h
