cmd_usr/include/asm/unistd.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/arch/arm64/include/uapi/asm/unistd.h usr/include/asm/unistd.h
