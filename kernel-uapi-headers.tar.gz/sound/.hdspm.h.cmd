cmd_usr/include/sound/hdspm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/hdspm.h usr/include/sound/hdspm.h
