cmd_usr/include/sound/usb_stream.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/usb_stream.h usr/include/sound/usb_stream.h
