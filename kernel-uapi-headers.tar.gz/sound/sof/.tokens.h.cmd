cmd_usr/include/sound/sof/tokens.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/sof/tokens.h usr/include/sound/sof/tokens.h
