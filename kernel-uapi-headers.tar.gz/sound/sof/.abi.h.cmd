cmd_usr/include/sound/sof/abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/sof/abi.h usr/include/sound/sof/abi.h
