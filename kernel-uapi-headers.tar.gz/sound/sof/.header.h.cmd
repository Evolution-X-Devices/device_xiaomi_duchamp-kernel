cmd_usr/include/sound/sof/header.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/sof/header.h usr/include/sound/sof/header.h
