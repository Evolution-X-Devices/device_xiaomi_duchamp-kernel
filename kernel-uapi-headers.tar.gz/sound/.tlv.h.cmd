cmd_usr/include/sound/tlv.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/tlv.h usr/include/sound/tlv.h
