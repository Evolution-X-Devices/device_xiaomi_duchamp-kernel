cmd_usr/include/sound/sb16_csp.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/sb16_csp.h usr/include/sound/sb16_csp.h
