cmd_usr/include/sound/asoc.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/asoc.h usr/include/sound/asoc.h
