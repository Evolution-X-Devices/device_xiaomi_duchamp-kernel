cmd_usr/include/sound/sfnt_info.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/sfnt_info.h usr/include/sound/sfnt_info.h
