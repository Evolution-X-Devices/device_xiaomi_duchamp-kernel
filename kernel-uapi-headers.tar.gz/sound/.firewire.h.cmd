cmd_usr/include/sound/firewire.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/firewire.h usr/include/sound/firewire.h
