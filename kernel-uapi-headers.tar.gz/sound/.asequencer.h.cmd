cmd_usr/include/sound/asequencer.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/asequencer.h usr/include/sound/asequencer.h
