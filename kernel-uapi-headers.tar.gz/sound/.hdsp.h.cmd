cmd_usr/include/sound/hdsp.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/hdsp.h usr/include/sound/hdsp.h
