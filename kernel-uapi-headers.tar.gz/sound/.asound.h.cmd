cmd_usr/include/sound/asound.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/asound.h usr/include/sound/asound.h
