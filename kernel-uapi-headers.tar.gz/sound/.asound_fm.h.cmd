cmd_usr/include/sound/asound_fm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/asound_fm.h usr/include/sound/asound_fm.h
