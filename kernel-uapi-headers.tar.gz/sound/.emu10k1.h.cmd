cmd_usr/include/sound/emu10k1.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/sound/emu10k1.h usr/include/sound/emu10k1.h
