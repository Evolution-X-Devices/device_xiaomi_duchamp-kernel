cmd_usr/include/scsi/scsi_netlink.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/scsi/scsi_netlink.h usr/include/scsi/scsi_netlink.h
