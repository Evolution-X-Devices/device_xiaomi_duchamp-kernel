cmd_usr/include/scsi/scsi_bsg_fc.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/scsi/scsi_bsg_fc.h usr/include/scsi/scsi_bsg_fc.h
