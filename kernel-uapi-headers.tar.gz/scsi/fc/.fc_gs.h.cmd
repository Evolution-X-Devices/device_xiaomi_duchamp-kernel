cmd_usr/include/scsi/fc/fc_gs.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/scsi/fc/fc_gs.h usr/include/scsi/fc/fc_gs.h
