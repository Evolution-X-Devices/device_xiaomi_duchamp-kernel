cmd_usr/include/scsi/scsi_bsg_ufs.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/scsi/scsi_bsg_ufs.h usr/include/scsi/scsi_bsg_ufs.h
