cmd_usr/include/misc/ocxl.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/misc/ocxl.h usr/include/misc/ocxl.h
