cmd_usr/include/misc/cxl.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/misc/cxl.h usr/include/misc/cxl.h
