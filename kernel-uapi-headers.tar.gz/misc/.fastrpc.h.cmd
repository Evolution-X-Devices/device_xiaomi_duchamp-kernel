cmd_usr/include/misc/fastrpc.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/misc/fastrpc.h usr/include/misc/fastrpc.h
