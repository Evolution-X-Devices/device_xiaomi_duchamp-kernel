cmd_usr/include/misc/pvpanic.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/misc/pvpanic.h usr/include/misc/pvpanic.h
