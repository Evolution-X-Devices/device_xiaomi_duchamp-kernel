cmd_usr/include/misc/xilinx_sdfec.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/misc/xilinx_sdfec.h usr/include/misc/xilinx_sdfec.h
