cmd_usr/include/misc/uacce/uacce.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/misc/uacce/uacce.h usr/include/misc/uacce/uacce.h
