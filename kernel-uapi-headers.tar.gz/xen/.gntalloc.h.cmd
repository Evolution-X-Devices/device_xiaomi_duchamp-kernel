cmd_usr/include/xen/gntalloc.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/xen/gntalloc.h usr/include/xen/gntalloc.h
