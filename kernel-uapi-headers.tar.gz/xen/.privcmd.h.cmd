cmd_usr/include/xen/privcmd.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/xen/privcmd.h usr/include/xen/privcmd.h
