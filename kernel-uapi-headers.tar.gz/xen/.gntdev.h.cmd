cmd_usr/include/xen/gntdev.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/xen/gntdev.h usr/include/xen/gntdev.h
