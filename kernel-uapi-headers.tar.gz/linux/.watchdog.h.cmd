cmd_usr/include/linux/watchdog.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/watchdog.h usr/include/linux/watchdog.h
