cmd_usr/include/linux/stm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/stm.h usr/include/linux/stm.h
