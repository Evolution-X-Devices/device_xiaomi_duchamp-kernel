cmd_usr/include/linux/seg6_hmac.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/seg6_hmac.h usr/include/linux/seg6_hmac.h
