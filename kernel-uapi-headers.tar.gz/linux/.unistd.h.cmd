cmd_usr/include/linux/unistd.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/unistd.h usr/include/linux/unistd.h
