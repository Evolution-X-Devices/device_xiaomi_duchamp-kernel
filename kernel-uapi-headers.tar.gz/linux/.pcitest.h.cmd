cmd_usr/include/linux/pcitest.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/pcitest.h usr/include/linux/pcitest.h
