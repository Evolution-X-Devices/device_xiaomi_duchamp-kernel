cmd_usr/include/linux/reboot.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/reboot.h usr/include/linux/reboot.h
