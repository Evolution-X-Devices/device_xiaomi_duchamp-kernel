cmd_usr/include/linux/pr.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/pr.h usr/include/linux/pr.h
