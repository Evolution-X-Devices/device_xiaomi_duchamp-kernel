cmd_usr/include/linux/vtpm_proxy.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/vtpm_proxy.h usr/include/linux/vtpm_proxy.h
