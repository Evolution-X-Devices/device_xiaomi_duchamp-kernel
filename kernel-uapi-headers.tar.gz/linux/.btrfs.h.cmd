cmd_usr/include/linux/btrfs.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/btrfs.h usr/include/linux/btrfs.h
