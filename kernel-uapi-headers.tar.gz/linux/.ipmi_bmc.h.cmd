cmd_usr/include/linux/ipmi_bmc.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/ipmi_bmc.h usr/include/linux/ipmi_bmc.h
