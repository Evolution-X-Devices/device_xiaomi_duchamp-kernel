cmd_usr/include/linux/nilfs2_api.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/nilfs2_api.h usr/include/linux/nilfs2_api.h
