cmd_usr/include/linux/tcp.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/tcp.h usr/include/linux/tcp.h
