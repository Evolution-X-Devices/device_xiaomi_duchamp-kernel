cmd_usr/include/linux/dlm_netlink.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/dlm_netlink.h usr/include/linux/dlm_netlink.h
