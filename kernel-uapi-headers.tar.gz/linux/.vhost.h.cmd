cmd_usr/include/linux/vhost.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/vhost.h usr/include/linux/vhost.h
