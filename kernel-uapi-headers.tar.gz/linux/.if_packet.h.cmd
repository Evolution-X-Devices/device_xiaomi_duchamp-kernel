cmd_usr/include/linux/if_packet.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/if_packet.h usr/include/linux/if_packet.h
