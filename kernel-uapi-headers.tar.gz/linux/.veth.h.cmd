cmd_usr/include/linux/veth.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/veth.h usr/include/linux/veth.h
