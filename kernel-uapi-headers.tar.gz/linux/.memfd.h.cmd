cmd_usr/include/linux/memfd.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/memfd.h usr/include/linux/memfd.h
