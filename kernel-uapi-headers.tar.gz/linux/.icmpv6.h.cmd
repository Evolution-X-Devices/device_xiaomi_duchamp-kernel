cmd_usr/include/linux/icmpv6.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/icmpv6.h usr/include/linux/icmpv6.h
