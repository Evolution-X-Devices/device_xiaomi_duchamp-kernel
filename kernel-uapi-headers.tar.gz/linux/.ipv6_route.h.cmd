cmd_usr/include/linux/ipv6_route.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/ipv6_route.h usr/include/linux/ipv6_route.h
