cmd_usr/include/linux/fdreg.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/fdreg.h usr/include/linux/fdreg.h
