cmd_usr/include/linux/arm_sdei.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/arm_sdei.h usr/include/linux/arm_sdei.h
