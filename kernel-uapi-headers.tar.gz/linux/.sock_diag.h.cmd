cmd_usr/include/linux/sock_diag.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/sock_diag.h usr/include/linux/sock_diag.h
