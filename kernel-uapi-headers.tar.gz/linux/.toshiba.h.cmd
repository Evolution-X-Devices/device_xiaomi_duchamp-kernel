cmd_usr/include/linux/toshiba.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/toshiba.h usr/include/linux/toshiba.h
