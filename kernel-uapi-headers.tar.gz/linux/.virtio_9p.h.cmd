cmd_usr/include/linux/virtio_9p.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/virtio_9p.h usr/include/linux/virtio_9p.h
