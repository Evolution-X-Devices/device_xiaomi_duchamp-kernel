cmd_usr/include/linux/stddef.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/stddef.h usr/include/linux/stddef.h
