cmd_usr/include/linux/icmp.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/icmp.h usr/include/linux/icmp.h
