cmd_usr/include/linux/virtio_fs.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/virtio_fs.h usr/include/linux/virtio_fs.h
