cmd_usr/include/linux/vmcore.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/vmcore.h usr/include/linux/vmcore.h
