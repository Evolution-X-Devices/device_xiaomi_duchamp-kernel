cmd_usr/include/linux/serial.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/serial.h usr/include/linux/serial.h
