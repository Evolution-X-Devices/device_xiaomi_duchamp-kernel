cmd_usr/include/linux/atm_nicstar.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/atm_nicstar.h usr/include/linux/atm_nicstar.h
