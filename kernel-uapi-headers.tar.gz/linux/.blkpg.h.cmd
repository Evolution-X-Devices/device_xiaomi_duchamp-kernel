cmd_usr/include/linux/blkpg.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/blkpg.h usr/include/linux/blkpg.h
