cmd_usr/include/linux/ptrace.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/ptrace.h usr/include/linux/ptrace.h
