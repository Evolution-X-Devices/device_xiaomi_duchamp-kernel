cmd_usr/include/linux/filter.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/filter.h usr/include/linux/filter.h
