cmd_usr/include/linux/genetlink.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/genetlink.h usr/include/linux/genetlink.h
