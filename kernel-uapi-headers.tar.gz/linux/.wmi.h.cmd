cmd_usr/include/linux/wmi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/wmi.h usr/include/linux/wmi.h
