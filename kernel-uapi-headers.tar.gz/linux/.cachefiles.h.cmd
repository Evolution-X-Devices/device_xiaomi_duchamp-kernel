cmd_usr/include/linux/cachefiles.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/cachefiles.h usr/include/linux/cachefiles.h
