cmd_usr/include/linux/rpmsg_types.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/rpmsg_types.h usr/include/linux/rpmsg_types.h
