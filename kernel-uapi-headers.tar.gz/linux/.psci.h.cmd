cmd_usr/include/linux/psci.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/linux/psci.h usr/include/linux/psci.h
