cmd_usr/include/rdma/bnxt_re-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/bnxt_re-abi.h usr/include/rdma/bnxt_re-abi.h
