cmd_usr/include/rdma/mlx5-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/mlx5-abi.h usr/include/rdma/mlx5-abi.h
