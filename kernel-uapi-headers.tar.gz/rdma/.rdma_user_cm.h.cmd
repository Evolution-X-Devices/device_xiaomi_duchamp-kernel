cmd_usr/include/rdma/rdma_user_cm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/rdma_user_cm.h usr/include/rdma/rdma_user_cm.h
