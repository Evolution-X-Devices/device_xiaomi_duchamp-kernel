cmd_usr/include/rdma/qedr-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/qedr-abi.h usr/include/rdma/qedr-abi.h
