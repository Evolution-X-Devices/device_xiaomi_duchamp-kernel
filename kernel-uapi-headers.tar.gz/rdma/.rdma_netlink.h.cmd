cmd_usr/include/rdma/rdma_netlink.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/rdma_netlink.h usr/include/rdma/rdma_netlink.h
