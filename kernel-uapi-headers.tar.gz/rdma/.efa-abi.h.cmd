cmd_usr/include/rdma/efa-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/efa-abi.h usr/include/rdma/efa-abi.h
