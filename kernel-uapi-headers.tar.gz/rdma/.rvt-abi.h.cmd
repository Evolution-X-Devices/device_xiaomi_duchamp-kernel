cmd_usr/include/rdma/rvt-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/rvt-abi.h usr/include/rdma/rvt-abi.h
