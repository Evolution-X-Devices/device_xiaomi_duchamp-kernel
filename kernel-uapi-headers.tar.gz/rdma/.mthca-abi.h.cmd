cmd_usr/include/rdma/mthca-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/mthca-abi.h usr/include/rdma/mthca-abi.h
