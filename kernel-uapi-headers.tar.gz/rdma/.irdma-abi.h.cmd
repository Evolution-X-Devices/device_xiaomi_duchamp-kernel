cmd_usr/include/rdma/irdma-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/irdma-abi.h usr/include/rdma/irdma-abi.h
