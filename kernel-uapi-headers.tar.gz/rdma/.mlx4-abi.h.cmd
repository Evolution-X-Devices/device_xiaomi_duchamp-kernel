cmd_usr/include/rdma/mlx4-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/mlx4-abi.h usr/include/rdma/mlx4-abi.h
