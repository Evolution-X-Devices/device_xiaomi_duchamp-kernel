cmd_usr/include/rdma/ib_user_sa.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/ib_user_sa.h usr/include/rdma/ib_user_sa.h
