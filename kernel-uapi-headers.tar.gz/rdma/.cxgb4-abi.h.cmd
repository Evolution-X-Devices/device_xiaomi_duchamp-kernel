cmd_usr/include/rdma/cxgb4-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/rdma/cxgb4-abi.h usr/include/rdma/cxgb4-abi.h
