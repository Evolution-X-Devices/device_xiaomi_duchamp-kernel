cmd_usr/include/mtd/mtd-abi.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/mtd/mtd-abi.h usr/include/mtd/mtd-abi.h
