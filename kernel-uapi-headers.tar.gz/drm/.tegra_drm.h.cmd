cmd_usr/include/drm/tegra_drm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/drm/tegra_drm.h usr/include/drm/tegra_drm.h
