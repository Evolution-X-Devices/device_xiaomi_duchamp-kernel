cmd_usr/include/drm/v3d_drm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/drm/v3d_drm.h usr/include/drm/v3d_drm.h
