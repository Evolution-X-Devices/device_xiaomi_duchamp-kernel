cmd_usr/include/drm/qxl_drm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/drm/qxl_drm.h usr/include/drm/qxl_drm.h
