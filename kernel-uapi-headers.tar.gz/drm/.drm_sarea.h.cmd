cmd_usr/include/drm/drm_sarea.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/drm/drm_sarea.h usr/include/drm/drm_sarea.h
