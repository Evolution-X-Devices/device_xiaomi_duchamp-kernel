cmd_usr/include/drm/i915_drm.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/drm/i915_drm.h usr/include/drm/i915_drm.h
