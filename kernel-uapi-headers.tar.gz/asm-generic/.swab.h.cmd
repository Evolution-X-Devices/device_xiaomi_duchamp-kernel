cmd_usr/include/asm-generic/swab.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/asm-generic/swab.h usr/include/asm-generic/swab.h
