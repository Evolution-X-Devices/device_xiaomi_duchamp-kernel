cmd_usr/include/asm-generic/setup.h := sh /home/mt6897a/kernel/kernel-6.1/scripts/headers_install.sh /home/mt6897a/kernel/kernel-6.1/include/uapi/asm-generic/setup.h usr/include/asm-generic/setup.h
